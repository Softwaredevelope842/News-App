package com.example.newsapp;

import com.example.newsapp.Models.NewsHeadlines;

public interface SelectListener {
    void OnNewClicked(NewsHeadlines headlines);
}
